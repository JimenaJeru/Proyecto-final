package com.example.dypanda;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class Adaptador extends RecyclerView.Adapter<Adaptador.ViewHolder>implements View.OnClickListener {
    private ArrayList<Vehiculo> listaVehiculos;
  //listener
    private  View.OnClickListener listener;
    public Adaptador(ArrayList<Vehiculo> listaVehiculos) {
        this.listaVehiculos = listaVehiculos;
    }

    @NonNull
    @Override
    public Adaptador.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.formato_formulario,null,false);
        view.setOnClickListener(this);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adaptador.ViewHolder holder, int position) {
        holder.asignarVehiculo(listaVehiculos.get(position));
    }

    @Override
    public int getItemCount() {
        return listaVehiculos.size();
    }

    public  void  setOnClickLister(View.OnClickListener listerx){
        this.listener=listerx;
    }

    @Override
    public void onClick(View view) {
        if(listener!=null)
        {
            listener.onClick(view);
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvId,tvPlaca,tvColor,tvModelo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvId = itemView.findViewById(R.id.tvKeyPropietario);
            tvColor = itemView.findViewById(R.id.tvNombrePropietario);
            tvPlaca = itemView.findViewById(R.id.tvCiPropietario);
            tvModelo = itemView.findViewById(R.id.tvCelularPropietario);
        }

        public void asignarVehiculo(Vehiculo vehiculo) {
            tvId.setText("id: "+vehiculo.getId());
            tvModelo.setText("Año: "+vehiculo.getModelo());
            tvPlaca.setText("Nombre Formulario: "+vehiculo.getPlaca());
            tvColor.setText("Mes: "+vehiculo.getColor());
        }
    }
}
