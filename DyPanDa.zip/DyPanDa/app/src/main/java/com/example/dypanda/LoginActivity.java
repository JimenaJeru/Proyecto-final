package com.example.dypanda;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;
    private FrameLayout frameLayoutt;
    private ArrayList<Vehiculo> listaVehiculos;
    private FragmentForm option1Fragment;
    private FragmentInfo option2Fragment;
    private RecyclerView rvListaVehiculosx;
    private Adaptador adaptador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        option2Fragment = new FragmentInfo();
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        frameLayoutt = findViewById(R.id.frameLayoutt);
        listaVehiculos = new ArrayList<Vehiculo>();
        option1Fragment = new FragmentForm();


        rvListaVehiculosx = findViewById(R.id.rvVehiculosx);
        rvListaVehiculosx.setLayoutManager(new GridLayoutManager(this,1));
        adaptador = new Adaptador(listaVehiculos);
        rvListaVehiculosx.setAdapter(adaptador);

        setFragment(option2Fragment);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.menu_home:
                        //bottomNavigationView.setItemBackgroundResource(R.color.colorPrimary);
                        setFragment(option1Fragment);
                        return true;
                    case R.id.menu_profile:
                        //bottomNavigationView.setItemBackgroundResource(R.color.colorPrimary);
                        setFragment(option2Fragment);
                        return true;
                    case R.id.menu_settings:
                        // bottomNavigationView.setItemBackgroundResource(R.color.colorPrimary)
                        finish();
                        return true;
                }
                return false;
            }
        });
    }

    private void setFragment(Fragment fragment) {
        FragmentTransaction fragmentTrasaction = getSupportFragmentManager().beginTransaction();
        fragmentTrasaction.replace(R.id.frameLayoutt, fragment);
        fragmentTrasaction.commit();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menuhori,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId()){
        case R.id.btnNew:
            Toast.makeText(getBaseContext(),"Nuevo Formulario",Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(),MainNewFor.class);
            startActivity(intent);
            break;
            case R.id.btnQR:
                Toast.makeText(getBaseContext(),"Escanear QR",Toast.LENGTH_SHORT).show();
                Intent in = new Intent(getApplicationContext(),Escaner.class);
                startActivity(in);
                break;
            case R.id.btnListQr:
                Toast.makeText(getBaseContext(),"Atrás",Toast.LENGTH_SHORT).show();


                break;
            case R.id.btnAtras:
                Toast.makeText(getBaseContext(),"Lista Formulario",Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(),lidtfor.class);
                startActivity(i);
                break;
            case R.id.btnAtrasx:
                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                builder.setMessage("¿Desea salir de DyPanDa?")
                        .setPositiveButton("Si", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent intent = new Intent(Intent.ACTION_MAIN);
                                intent.addCategory(Intent.CATEGORY_HOME);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        });
                builder.show();
                break;



         }
         return super.onOptionsItemSelected(item);
    }

}
