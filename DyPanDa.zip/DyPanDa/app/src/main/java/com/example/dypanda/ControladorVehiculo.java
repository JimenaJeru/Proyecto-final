package com.example.dypanda;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class ControladorVehiculo {
    private AyudanteSqlite ayudanteSqlite;

    public ControladorVehiculo(Context context) {
        ayudanteSqlite = new AyudanteSqlite(context);
    }

    public long insertarVehiculo(Vehiculo vehiculo){
        SQLiteDatabase sqLiteDatabase = ayudanteSqlite.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("placa",vehiculo.getPlaca());
        contentValues.put("color",vehiculo.getColor());
        contentValues.put("modelo",vehiculo.getModelo());

        return sqLiteDatabase.insert(ayudanteSqlite.getNombreTabla(),null,contentValues);
    }
}
