package com.example.dypanda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainNewFactura extends AppCompatActivity {



    EditText edtNombre,edFactura,edtAutoriza,edtFech,edtTotal,edtCodigo,edtNumkey;
    Button btnguradar;
    private Vehiculo vehiculo;
    private ArrayList<Vehiculo> listaVehiculos;
    private Adaptador adaptador;
    String numfax="fgh";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_new_factura);
        listaVehiculos = new ArrayList<Vehiculo>();
        //Necesitamos cargar la lista desde la tabla SQLITE

        adaptador = new Adaptador(listaVehiculos);
        edtNombre=(EditText)findViewById(R.id.edtProvedor);
        edFactura=(EditText)findViewById(R.id.edtFactura);
        edtAutoriza=(EditText)findViewById(R.id.edtAutorizacion);
        edtFech=(EditText)findViewById(R.id.edtFecha);
        edtTotal=(EditText)findViewById(R.id.edtTotal);
        edtCodigo=(EditText)findViewById(R.id.edtControl);
        btnguradar=(Button)findViewById(R.id.btnGuardarf);
        edtNumkey=(EditText)findViewById(R.id.edtNumkey);

        String dato=getIntent().getStringExtra("idefor");
        edtNumkey.setText(" "+dato);
        final  DeveloperuBD developeruBD=new DeveloperuBD(getApplicationContext());

        btnguradar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                developeruBD.agregarCursos(edtNombre.getText().toString(),edFactura.getText().toString(),edtAutoriza.getText().toString(),edtFech.getText().toString(),
                        edtTotal.getText().toString(),edtCodigo.getText().toString(),edtNumkey.getText().toString());
                Toast.makeText(getApplicationContext(),"Se agrego factura ",Toast.LENGTH_SHORT).show();

            }
        });


    }

}