package com.example.dypanda;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Factura extends AppCompatActivity {

TextView nombrex,aniox,mesx,x;
Button NuewFactura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_factura);
        NuewFactura=(Button)findViewById(R.id.btnNewFacru);
        nombrex=(TextView)findViewById(R.id.txtNombreFac);
        aniox=(TextView)findViewById(R.id.txtAniofa);
        x=(TextView)findViewById(R.id.nufor);


        mesx=(TextView)findViewById(R.id.txtMesfa);
        String dato=getIntent().getStringExtra("nombref");
        nombrex.setText(" "+dato);
        String dato1=getIntent().getStringExtra("aniof");
        aniox.setText(" Mes: "+dato1);
        String dato2=getIntent().getStringExtra("mesf");
        mesx.setText("Año: "+dato2);
        String dato3=getIntent().getStringExtra("id");
        x.setText("Nor.Formulario: "+dato2);
        NuewFactura.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Factura.this,MainNewFactura.class);
                startActivity(intent);

            }
        });
        Intent i = new Intent(getApplicationContext(),MainNewFactura.class);
        startActivity(i);
        i.putExtra("idefor",dato2);


    }



    }
