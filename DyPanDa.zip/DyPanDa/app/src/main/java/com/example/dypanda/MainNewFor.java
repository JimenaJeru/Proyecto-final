package com.example.dypanda;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainNewFor extends AppCompatActivity {
    private EditText etPlaca,etColor,etModelo;
    private Button btnGuardar;
    private RecyclerView rvListaVehiculos;
    private ControladorVehiculo controladorVehiculo;
    private Vehiculo vehiculo;
    private ArrayList<Vehiculo> listaVehiculos;
    private Adaptador adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_new_for);
        etPlaca = findViewById(R.id.etPlaca);
        etColor = findViewById(R.id.etColor);
        etModelo = findViewById(R.id.etModelo);
        btnGuardar = findViewById(R.id.btnGuardar);

        controladorVehiculo = new ControladorVehiculo(MainNewFor.this);
        vehiculo = new Vehiculo();
        listaVehiculos = new ArrayList<Vehiculo>();
        //Necesitamos cargar la lista desde la tabla SQLITE
        cargarVehiculosSqlite();




        //evento click del boton agregar
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Vamos a leer todos los datos del vihiculo
                String placaString = etPlaca.getText().toString().trim();
                String colorString = etColor.getText().toString().trim();
                String modeloString = etModelo.getText().toString().trim();
                if (placaString.equals("")){
                    etPlaca.setError("Ingresa la Nombre de Formulario");
                    etPlaca.requestFocus();
                    return;
                }
                if (modeloString.equals("")){
                    etModelo.setError("Ingresa el Año");
                    etModelo.requestFocus();
                    return;
                }
                if (colorString.equals("")){
                    etColor.setError("Ingresa el Mes");
                    etColor.requestFocus();
                    return;
                }

                int modeloInt = Integer.parseInt(modeloString);
                //ahora crearemos el objeto con los datos obtenidos de la IU
                vehiculo = new Vehiculo(placaString,colorString,modeloInt);
                long resultado = controladorVehiculo.insertarVehiculo(vehiculo);
                if (resultado==-1){
                    //error al insertar
                    Toast.makeText(getApplicationContext(),"Error al insertar Formulario", Toast.LENGTH_LONG).show();
                }else{
                    //se inserto correctamente
                    Toast.makeText(getApplicationContext()," Nuevo Formulario insertado ", Toast.LENGTH_LONG).show();
                    cargarVehiculosSqlite();
                    adaptador = new Adaptador(listaVehiculos);
                    rvListaVehiculos.setAdapter(adaptador);
                    limpiarFormulario();
                }
            }
        });

    }

    private void limpiarFormulario() {
        etModelo.setText("");
        etColor.setText("");
        etPlaca.setText("");
    }

    private void cargarVehiculosSqlite() {
        try {
            listaVehiculos = new ArrayList<Vehiculo>();
            String placaString,colorString;
            int idInt,modeloInt;
            AyudanteSqlite ayudanteSqlite = new AyudanteSqlite(MainNewFor.this);
            SQLiteDatabase sqLiteDatabase = ayudanteSqlite.getReadableDatabase();
            Cursor cursor = sqLiteDatabase.rawQuery("select id,placa,modelo,color from vehiculo",null);
            if (cursor.moveToFirst()){
                do {
                    idInt = cursor.getInt(0);
                    placaString = cursor.getString(1);
                    modeloInt = cursor.getInt(2);
                    colorString = cursor.getString(3);
                    Vehiculo vehiculoAux = new Vehiculo(placaString,colorString,idInt,modeloInt);
                    listaVehiculos.add(vehiculoAux);
                }while(cursor.moveToNext());
            }else{
                Toast.makeText(getApplicationContext(),"No existen Formulario registrados", Toast.LENGTH_LONG).show();
            }
        }catch (Exception ex){
            Toast.makeText(getApplicationContext(),"Error al cargar Formularios de Sqlite", Toast.LENGTH_LONG).show();
        }
    }
}