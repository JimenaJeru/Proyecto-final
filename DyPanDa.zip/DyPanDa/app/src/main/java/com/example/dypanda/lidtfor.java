package com.example.dypanda;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class lidtfor extends AppCompatActivity {



    private EditText etPlaca, etColor, etModelo;
    private Button btnGuardar;
    private RecyclerView rvListaVehiculos;
    private ControladorVehiculo controladorVehiculo;
    private Vehiculo vehiculo;
    private ArrayList<Vehiculo> listaVehiculos;
    private Adaptador adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lidtfor);





        rvListaVehiculos = findViewById(R.id.listtext);
        rvListaVehiculos.setLayoutManager(new GridLayoutManager(this,1));
        controladorVehiculo = new ControladorVehiculo(lidtfor.this);
        vehiculo = new Vehiculo();
        listaVehiculos = new ArrayList<Vehiculo>();
        //Necesitamos cargar la lista desde la tabla SQLITE
        cargarVehiculosSqlite();
        adaptador = new Adaptador(listaVehiculos);
        rvListaVehiculos.setAdapter(adaptador);


        //evento click del boton agregar
        adaptador.setOnClickLister(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre= listaVehiculos.get(rvListaVehiculos.getChildAdapterPosition(view)).getPlaca();
                String anio= listaVehiculos.get(rvListaVehiculos.getChildAdapterPosition(view)).getColor();
                int num= listaVehiculos.get(rvListaVehiculos.getChildAdapterPosition(view)).getModelo();
                int id= listaVehiculos.get(rvListaVehiculos.getChildAdapterPosition(view)).getId();
                Toast.makeText(getApplicationContext(),"Selecciono:"+nombre,Toast.LENGTH_SHORT).show();




                Intent i = new Intent(getApplicationContext(),Factura.class);
                startActivity(i);
                i.putExtra("nombref",nombre);
                startActivity(i);
                i.putExtra("aniof",anio);
                startActivity(i);
                String numx=Integer.toString(num);
                i.putExtra("mesf",numx);
                startActivity(i);

                String idc=Integer.toString(id);
                i.putExtra("id",idc);
                startActivity(i);


                //enviar datos a la otra activity

            }
        });


    }

    private void limpiarFormulario() {
        etModelo.setText("");
        etColor.setText("");
        etPlaca.setText("");
    }

    private void cargarVehiculosSqlite() {
        try {
            listaVehiculos = new ArrayList<Vehiculo>();
            String placaString,colorString;
            int idInt,modeloInt;
            AyudanteSqlite ayudanteSqlite = new AyudanteSqlite(lidtfor.this);
            SQLiteDatabase sqLiteDatabase = ayudanteSqlite.getReadableDatabase();
            Cursor cursor = sqLiteDatabase.rawQuery("select id,placa,modelo,color from vehiculo",null);

            if (cursor.moveToFirst()){

                do {
                    idInt = cursor.getInt(0);
                    placaString = cursor.getString(1);
                    modeloInt = cursor.getInt(2);
                    colorString = cursor.getString(3);
                    Vehiculo vehiculoAux = new Vehiculo(placaString,colorString,idInt,modeloInt);
                    listaVehiculos.add(vehiculoAux);

                }while(cursor.moveToNext());

            }else{
                Toast.makeText(getApplicationContext(),"No existen Formulario registrados", Toast.LENGTH_LONG).show();
            }

        }catch (Exception ex){
            Toast.makeText(getApplicationContext(),"Error al cargar Formulario de Sqlite", Toast.LENGTH_LONG).show();
        }

    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menuhori,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId()){
            case R.id.btnNew:
                Toast.makeText(getBaseContext(),"Nuevo Formulario",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),MainNewFor.class);
                startActivity(intent);
                break;
            case R.id.btnQR:
                Toast.makeText(getBaseContext(),"btQR",Toast.LENGTH_SHORT).show();
                break;
            case R.id.btnListQr:
                Toast.makeText(getBaseContext(),"LIst",Toast.LENGTH_SHORT).show();

                Intent i = new Intent(getApplicationContext(),lidtfor.class);
                startActivity(i);
                break;
            case R.id.btnAtras:
                Toast.makeText(getBaseContext(),"Atrás",Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}