package com.example.dypanda;

public class Vehiculo {
    private String placa,color;
    private int id,modelo;

    public Vehiculo() {
    }
    public Vehiculo(String placa, String color, int modelo) {
        this.placa = placa;
        this.color = color;
        this.modelo = modelo;
    }
    public Vehiculo(String placa, String color, int id, int modelo) {
        this.placa = placa;
        this.color = color;
        this.id = id;
        this.modelo = modelo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getModelo() {
        return modelo;
    }
    public void setModelo(int modelo) {
        this.modelo = modelo;
    }
}
