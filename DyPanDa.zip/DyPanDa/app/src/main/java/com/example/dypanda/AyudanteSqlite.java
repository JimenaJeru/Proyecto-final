package com.example.dypanda;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class AyudanteSqlite extends SQLiteOpenHelper {

    private static final String NOMBRE_BD = "concesionaria.db",NOMBRE_TABLA="vehiculo";

    public AyudanteSqlite(@Nullable Context context) {
        super(context, NOMBRE_BD, null, 1);
    }

    public static String getNombreBd() {
        return NOMBRE_BD;
    }
    public static String getNombreTabla() {
        return NOMBRE_TABLA;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(String.format("create table if not exists %s(id integer primary key autoincrement,placa text not null,color text not null,modelo integer not null);",NOMBRE_TABLA));
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
